/*
 * @Author: 崔鼎 1692338302@qq.com
 * @Date: 2023-09-13 14:45:09
 * @LastEditors: 崔鼎 1692338302@qq.com
 * @LastEditTime: 2023-09-13 15:04:39
 * @FilePath: \全栈之路\富文本学习\TinyMCE\src\MyTiny.d.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
declare module "@/components/MyTiny/index" {
  import Vue from 'vue';

  export default class MyTiny {
      // 这里定义组件的属性、方法和事件等
      myValue: string;
  }
}